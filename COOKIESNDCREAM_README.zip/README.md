# COOKIESNDCREAM -- Personal Task Manager

A simple **Laravel Personal Task Manager** that allows users to add,
view, edit, delete, and update the status of their tasks.

## Project Information

  Information         Details
  ------------------- -----------------------------------------
  **Project Name**    COOKIESNDCREAM -- Personal Task Manager
  **Project Code**    WST21-PM-2026-SF
  **Course & Year**   BSIT -- 2nd Year
  **Framework**       Laravel
  **Database**        SQLite

## Features

-   Add Task
-   View Tasks
-   Edit Task
-   Delete Task
-   Update Task Status
-   Set Due Date
-   Add Task Description
-   Success messages after adding or updating a task

## Database

The system uses an **SQLite database**.

### `tasks` Table

  Field           Description
  --------------- ---------------------------
  `id`            Task ID
  `task_name`     Name of the task
  `description`   Task details
  `status`        Pending or Completed
  `due_date`      Task deadline
  `created_at`    Date the task was created
  `updated_at`    Date the task was updated

## Laravel Structure

The project follows the basic Laravel flow:

**Routes → Controller → Model → Database → Blade Views**

-   **Routes** -- Handles the URLs and connects them to controller
    methods.
-   **Controller** -- Handles adding, viewing, editing, updating,
    deleting, and changing task status.
-   **Model** -- The `Task` model communicates with the SQLite database.
-   **Database** -- Stores the task information.
-   **Blade Views** -- Displays the task manager interface.

# Dashboard Walkthrough

## Image 1: Review and Manage Tasks

The dashboard displays the existing tasks together with their
descriptions, status, due dates, and action buttons.

1.  View the list of saved tasks.
2.  Check the task description and due date.
3.  Select **Complete** to change a task from Pending to Completed.
4.  Select **Edit** to modify a task.
5.  Select **Delete** to remove a task.

![Dashboard](image1-dashboard.jfif)

## Image 2: Add a Task

The Add New Task page is used to create a new task.

1.  Enter a name in **Task Name**. This field is required.
2.  Add details in **Description** if needed.
3.  Select a **Status**.
4.  Choose a **Due Date**.
5.  Select **Save Task** to add the task.

![Add Task](image2-add-task.jfif)

## Image 3: Task List After Saving

After saving a task, the system returns to the task list and displays
the saved tasks.

1.  The new task appears in the dashboard.
2.  The task name and description are displayed.
3.  The current status is shown.
4.  The due date is displayed when available.
5.  The task can be completed, edited, or deleted using the action
    buttons.

![Task List](image3-task-list.jfif)

# How to Run the Project

### 1. Install Dependencies

``` bash
composer install
```

### 2. Create the Environment File

``` bash
copy .env.example .env
```

### 3. Generate the Application Key

``` bash
php artisan key:generate
```

### 4. Configure SQLite

Create the database file:

``` text
database/database.sqlite
```

Make sure the `.env` file uses SQLite:

``` env
DB_CONNECTION=sqlite
```

### 5. Run the Migration

``` bash
php artisan migrate
```

### 6. Start the Laravel Server

``` bash
php artisan serve
```

Open the application in your browser:

``` text
http://127.0.0.1:8000
```

# Conclusion

**COOKIESNDCREAM Personal Task Manager** provides a simple way to
organize and manage personal tasks using Laravel, SQLite, Controllers,
Models, Routes, and Blade Views.
